#include <iostream>
using namespace std;

int main ()
{
    int t;
    cin >> t;
    while (t--)
    {
	int iNum;
	cin >> iNum;
	if (10 == iNum)
	{
	    cout << "YES" << endl;
	}
	else
	{
	    if (iNum % 2 == 0)
	    {
		cout << "NO" << endl;
	    }
	    else
	    {
		cout << "YES" << endl;
	    }
	}
    }
    return 0;
}

// end
// ismdeep
// CodeLab
