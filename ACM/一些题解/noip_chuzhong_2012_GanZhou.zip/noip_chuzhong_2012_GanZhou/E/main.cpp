#include <iostream>
#include <cstdio>
#include <cmath>
using namespace std;

typedef unsigned long long longint;

longint iTop[9];
longint iMap[9][2200];

bool is_prime (longint iNum)
{
    longint iStop = sqrt ((double) ((double)iNum + (double)0.5));
    bool yes = true;
    for (int i = 2; yes && i <= iStop; i++)
    {
	if (iNum % i == 0)
	{
	    yes = false;
	}
    }
    if (1 == iNum || 0 == iNum)
    {
	yes = false;
    }
    return yes;
}

void init_iTop ()
{
    for (int index = 0; index < 9; index++)
    {
	iTop[index] = -1;
    }
}

void make_iMap ()
{
    iTop[0] = 0;
    iMap[0][iTop[0]] = 0;
    for (int index = 1; index <= 8; index++)
    {
	for (int i = 0; i <= iTop[index-1]; i++)
	{
	    for (int j = 0; j <= 9; j++)
	    {
		if (is_prime(iMap[index-1][i] * 10 + j))
		{
		    iTop[index]++;
		    iMap[index][iTop[index]] = iMap[index-1][i] * 10 + j;
		}
	    }
	}
    }
}

int main ()
{
    init_iTop ();
    make_iMap ();
    int index;
    while (cin >> index)
    {
	cout << "-------------------------------------------------------------------------" << endl;
	cout << index << " : " << endl;
	for (int i = 0; i <= iTop[index]; i++)
	{
	    cout << iMap[index][i] << " ";
	}
	cout << endl;
	// cout << endl << endl << endl;
    }
    return 0;
}
// end
// ismdeep
// CodeLab

