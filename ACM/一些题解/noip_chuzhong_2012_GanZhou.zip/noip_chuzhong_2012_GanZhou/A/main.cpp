#include <iostream>
#include <cmath>
#include <cstdio>
using namespace std;

#define _ISM_DEBUG_

#ifndef MAXN
#define MAXN 1100
#endif

struct Point
{
    int x;
    int y;
};

Point iPointData[MAXN];
int n;

double distance_of_point (Point pa, Point pb)
{
    return sqrt(((pa.x - pb.x) * (pa.x - pb.x)) + ((pa.y - pb.y) * (pa.y - pb.y)));
}

double cal_triangle_area_by_side_length (double length_a, double length_b, double length_c)
{
    double dou_p;
    dou_p = (length_a + length_b + length_c) / (double)2;
    return sqrt((double)(dou_p * (dou_p - length_a) * (dou_p - length_b) * (dou_p - length_c)));
}

double cal_triangle_area_by_point_position (Point pa, Point pb, Point pc)
{
    double length_a;
    double length_b;
    double length_c;
    length_a = distance_of_point (pb, pc);
    length_b = distance_of_point (pa, pc);
    length_c = distance_of_point (pa, pb);
    return cal_triangle_area_by_side_length (length_a, length_b, length_c);
}

void input_iPointData ()
{
    for (int i = 0; i < n; i++)
    {
	cin >> iPointData[i].x >> iPointData[i].y;
    }
}

double cal_iPointData_area ()
{
    double sum_area = 0.0;
    double tmp_area = 0.0;
    for (int index = 1; index <= n - 2; index++)
    {
	tmp_area = cal_triangle_area_by_point_position (iPointData[0], iPointData[index], iPointData[index+1]);
	sum_area += tmp_area;
    }
    return sum_area;
}

int main ()
{
    while (cin >> n && n > 0)
    {
	input_iPointData ();
	printf ("%.2lf\n", cal_iPointData_area ());
    }
    return 0;
}

// end 
// ismdeep
// CodeLab
//

