#include <iostream>
using namespace std;

#define _ISM_DEBUG_

#ifndef MAXN
#define MAXN 11000
#endif

int palindrome[MAXN];
int iTop = 0;

bool is_palindrome (int iNum)
{
    int digit [5];
    for (int i = 0; i < 5; i++)
    {
	digit[i] = iNum % 10;
	iNum /= 10;
    }
    return (digit[0] == digit[4] && digit[1] == digit[3]);
}

void make_palindrome_list ()
{
    for (int iNum = 10001; iNum <= 99999; iNum++)
    {
	if (is_palindrome(iNum))
	{
	    iTop++;
	    palindrome[iTop] = iNum;
	}
    }
}

void show_palindrome_list ()
{
    for (int index = 1; index <= iTop; index++)
    {
	cout << index << " - " << palindrome[index] << endl; 
    }
}

int main ()
{
    make_palindrome_list ();
    // show_palindrome_list ();
    int iIndex;
    while (cin >> iIndex)
    {
	cout << palindrome[iIndex] << endl;
    }
    return 0;
}

// end
// ismdeep
// CodeLab
