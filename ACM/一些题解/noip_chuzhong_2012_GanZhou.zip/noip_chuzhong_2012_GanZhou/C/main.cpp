#include <iostream>
using namespace std;

void show_up   (int iLength)
{
    for (int index = 1; index <= iLength; index++)
    {
	for (int j = 1; j < index; j++)
	{
	    cout << "O";
	}
	cout << "Y";
	for (int j = 1; j <= (iLength * 2 + 1 - index * 2); j++)
	{
	    cout << "O";
	}
	cout << "Y";
	for (int j = 1; j < index; j++)
	{
	    cout << "O";
	}
	cout << endl;
    }
}

void show_mid  (int iLength)
{
    for (int j = 1; j <= iLength; j++)
    {
	cout << "O";
    }
    cout << "X";
    for (int j = 1; j <= iLength; j++)
    {
	cout << "O";
    }
    cout << endl;
}

void show_down (int iLength)
{
    for (int index = iLength; index >= 1; index--)
    {
	for (int j = 1; j < index; j++)
	{
	    cout << "O";
	}
	cout << "Y";
	for (int j = 1; j <= (iLength * 2 + 1 - index * 2); j++)
	{
	    cout << "O";
	}
	cout << "Y";
	for (int j = 1; j < index; j++)
	{
	    cout << "O";
	}
	cout << endl;
    }
}

int main ()
{
    int n;
    while (cin >> n)
    {
	int iLength;
	iLength = (n - 1) / 2;
	show_up   (iLength);
	show_mid  (iLength);
	show_down (iLength);
    }
    return 0;
}

// end
// ismdeep
// CodeLab
