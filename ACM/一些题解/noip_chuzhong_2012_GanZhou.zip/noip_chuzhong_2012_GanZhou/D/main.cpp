#include <iostream>
#include <cstdio>
using namespace std;

bool judge_function (int a, int b, int c, int d, int e, int f)
{
    bool yes = true;
    // a ，b两样至少有一样
    if (a == 0 && b == 0)
    {
	yes = false;
    }
    // a ，d不能同时取
    if (a == 1 && d == 1)
    {
	yes = false;	    
    }
    // a ，e ，f中必须有两样
    if (a + e + f < 2)
    {
	yes = false;
    }
    // b ，c要么都选，要么都不选
    if (b + c == 1)
    {
	yes = false;
    }
    // c ，d两样中选一样
    if (c + d == 2 || c + d == 0)
    {
	yes = false;
    }
    // 若d不选，则e也不选
    if (0 == d && 1 == e)
    {
	yes = false;
    }
    return yes;
}

int main ()
{
    int a, b, c, d, e, f;
    for (a = 0; a <= 1; a++)
    {
	for (b = 0; b <= 1; b++)
	{
	    for (c = 0; c <= 1; c++)
	    {
		for (d = 0; d <= 1; d++)
		{
		    for (e = 0; e <= 1; e++)
		    {
			for (f = 0; f <= 1; f++)
			{
			    if ( judge_function (a, b, c, d, e, f) )
			    {
				printf ("a=%d,b=%d,c=%d,d=%d,e=%d,f=%d\n",a , b, c, d, e, f);
			    }
			}
		    }
		}
	    }
	}
    }
    return 0;
}
// end
// ismdeep
// CodeLab
